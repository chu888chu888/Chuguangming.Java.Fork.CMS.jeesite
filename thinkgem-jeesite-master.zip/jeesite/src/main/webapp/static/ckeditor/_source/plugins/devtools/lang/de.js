﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'devtools', 'de',
{
	devTools :
	{
		title		: 'Elementinformation',
		dialogName	: 'Dialogfenstername',
		tabName		: 'Reitername',
		elementId	: 'Element ID',
		elementType	: 'Elementtyp'
	}
});
